import React from "react";
import Slider from "./Slider";
import LeftSection from "./LeftSection";
import RightSection from "./RightSection";
import banner from "/./img/banner-img.PNG";
import Footer from "./Footer";

function Home() {
  return (
    <div>
      <img className="banner" src={banner} alt="sub slider" />
      <Slider />

      <div class="main">
        <div className="left">
          <LeftSection />
        </div>
        <div className="right">
          <RightSection />
        </div>
      </div>
      <div class="footer">
        <Footer />
      </div>
    </div>
  );
}

export default Home;
