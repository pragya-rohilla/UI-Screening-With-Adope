import React, { Fragment } from "react";

// const data = {
//   body: [
//     {
//       component: "1-"
//     },
//     {
//       component: "2-"
//     },
//     {
//       component: "3-"
//     }
//   ]
// };

const productList = [
  "ALL",
  "Photoshop",
  "InDesign",
  "Dreamwearver",
  "Lightroom Classic",
  "Lightroom",
  "Muse",
  "Premier Pro",
  "After Ellect",
  "InCopy",
  "Animate",
  "Acobat Pro",
  "Prelude",
  "Audition"
];

const popularTags = [
  "3D",
  "Actions",
  "Brushes",
  "Ellects",
  "Gradients,",
  "Painting",
  "Photo editing",
  "Presets",
  "Printing",
  "Templates",
  "Video editing"
];

function LeftSection() {
  return (
    <>
      <h5>View By Products</h5>
      <ul className="productList">
        {/* {data.body.map((block) => {
        return <p>{block.component}</p>;
      })} */}
        {productList.map((block) => {
          return (
            <li>
              <a href="">{block}</a>
            </li>
          );
        })}
      </ul>
      <hr />
      <h5>View By Popular Tags</h5>
      <ul className="popularTags">
        {popularTags.map((block) => {
          return (
            <li>
              <input type="checkbox" />
              {block}
            </li>
          );
        })}
      </ul>
    </>
  );
}

export default LeftSection;
