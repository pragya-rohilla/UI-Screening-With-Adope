import React from "react";

function Creativecloud() {
  return (
    <div>
      <h2>Hi, This is Creative cloud Page</h2>
    </div>
  );
}

export default Creativecloud;
