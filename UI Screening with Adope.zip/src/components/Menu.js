import React, { Component } from "react";
import { FaAlignRight } from "react-icons/fa";
import { Link } from "react-router-dom";
import logo from "/./img/Adobe_Corporate_Horizontal_Red_HEX.svg";
import search from "/./img/search.png";
import Popup from "reactjs-popup";
import "reactjs-popup/dist/index.css";
export default class Menu extends Component {
  state = {
    toggle: false
  };
  Toggle = () => {
    this.setState({ toggle: !this.state.toggle });
  };
  render() {
    return (
      <>
        <div className="navBar">
          <button onClick={this.Toggle}>
            <FaAlignRight />
          </button>
          <ul
            className={this.state.toggle ? "nav-links show-nav" : "nav-links"}
          >
            <li>
              <Link to="/">
                <img src={logo} className="logo" alt="logo" />
                <span> Adobe Exchange</span>
              </Link>
            </li>
            <li>
              <Link to="Creativecloud">Creative Cloud</Link>
            </li>
            <li>
              <Link to="Experiencecloud">Experience Cloud</Link>
            </li>
            <li>
              <Link to="Documentcloud">Document Cloud</Link>
            </li>
          </ul>

          <ul
            className={this.state.toggle ? "nav-links show-nav" : "nav-links"}
          >
            <li>
              <input type="text" />
              <img src={search} className="search" alt="search" />
            </li>
            <li>
              {/* <button type="button" className="signIn">
            Sign In
          </button> */}
              <button className="signIn"> Sign In</button>
            </li>
          </ul>
        </div>
      </>
    );
  }
}
