import React from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from "react-responsive-carousel";
import banner1 from "/./img/banner1.jpg";
import banner2 from "/./img/banner2.jpg";

function Slider() {
  return (
    <Carousel>
      <div className="pics">
        <div className="sec-1">
          <img src={banner1} alt="Slider 1" />
          <p>Brand launch Extension</p>
          <p className="branch">Branch Matrics</p>
        </div>
        <div className="sec-1">
          <img src={banner2} alt="Slider 1" />
          <p>Brand launch Extension</p>
          <p className="branch">Branch Matrics</p>
        </div>

        <div className="sec-1">
          <img src={banner1} alt="Slider 1" />
          <p>Brand launch Extension</p>
          <p className="branch">Branch Matrics</p>
        </div>

        <div className="sec-1">
          <img src={banner1} alt="Slider 1" />
          <p>Brand launch Extension</p>
          <p className="branch">Branch Matrics</p>
        </div>
      </div>
      <div className="pics">
        <div className="sec-1">
          <img src={banner1} alt="Slider 1" />
          <p>Brand launch Extension</p>
          <p className="branch">Branch Matrics</p>
        </div>
        <div className="sec-1">
          <img src={banner2} alt="Slider 1" />
          <p>Brand launch Extension</p>
          <p className="branch">Branch Matrics</p>
        </div>

        <div className="sec-1">
          <img src={banner1} alt="Slider 1" />
          <p>Brand launch Extension</p>
          <p className="branch">Branch Matrics</p>
        </div>

        <div className="sec-1">
          <img src={banner1} alt="Slider 1" />
          <p>Brand launch Extension</p>
          <p className="branch">Branch Matrics</p>
        </div>
      </div>
    </Carousel>
  );
}

export default Slider;
