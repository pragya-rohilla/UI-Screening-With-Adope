import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import logo from "/./img/Adobe_Corporate_Horizontal_Red_HEX.svg";
import search from "/./img/search.png";
import Popup from "reactjs-popup";
import "reactjs-popup/dist/index.css";
import Menu from "./Menu";

function Header() {
  return (
    <Fragment>
      <Menu />
    </Fragment>
  );
}

export default Header;
