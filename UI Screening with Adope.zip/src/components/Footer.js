import React from "react";

function Footer() {
  return (
    <div>
      <div className="flexClass">
        <div class="apis">
          {/* <h4>APIs</h4> */}
          <ul>
            <li>APIs</li>
            <li>Creative Cloud</li>
            <li>Document Cloud</li>
            <li>Experience Cloud</li>
          </ul>
        </div>

        <div class="blogs">
          {/* <h4>Blogs & Community</h4> */}
          <ul>
            <li>Blogs & Community</li>
            <li>Adope Tech Blog</li>
            <li>Adope on Github</li>
          </ul>
        </div>

        <div class="developer">
          {/* <h4>Developer Resources</h4> */}
          <ul>
            <li>Developer Resources</li>
            <li>Go to Adope to create plugin</li>
            <li>Go to exchange portal to publish plugins</li>
          </ul>
        </div>

        <div class="users">
          {/* <h4>Users Resources</h4> */}
          <ul>
            <li>Users Resources</li>
            <li>Forms</li>
            <li>Help & troubleshooting</li>
          </ul>
        </div>

        <div class="Suport">
          {/* <h4>Support</h4> */}
          <ul>
            <li>Support</li>
            <li>Contact Us</li>
            <li>Adope Developer Support</li>
            <li>Adope Product Support</li>
            <li>Release Note</li>
          </ul>
        </div>
      </div>
      <div className="follow">
        {/* <h4>Follow US</h4> */}
        <ul>
          <li>Follow US</li>
          <li>facebook</li>
          <li>Google</li>
          <li>LinkedIn</li>
        </ul>
      </div>
    </div>
  );
}

export default Footer;
