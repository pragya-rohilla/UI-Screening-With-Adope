import React from "react";

function Documentcloud() {
  return (
    <div>
      <h2>Hi, This is Document cloud Page</h2>
    </div>
  );
}

export default Documentcloud;
