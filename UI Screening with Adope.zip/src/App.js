import React from "react";
import Documentcloud from "./components/Documentcloud";
import Creativecloud from "./components/Creativecloud";
import Experiencecloud from "./components/Experiencecloud";
import "./styles.css";
import { BrowserRouter, Route } from "react-router-dom";
import Home from "./components/Home";
import Header from "./components/Header";

export default function App() {
  return (
    <BrowserRouter>
      <Header />
      <div className="container">
        <switch>
          <Route path="/" exact component={Home} />
          <Route path="/Documentcloud" component={Documentcloud} />
          <Route path="/Creativecloud" component={Creativecloud} />
          <Route path="/Experiencecloud" component={Experiencecloud} />
        </switch>
      </div>
    </BrowserRouter>
  );
}
